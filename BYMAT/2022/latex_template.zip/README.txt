Please fill out the template according to the following steps. Do not change the names of the .tex files.

Step 1: Open the file 'template.tex'.

Step 2: Fill out the template. Please do not use any macros, environments, citations, references, footnotes or similar things (just as in abstracts of research articles). Also avoid custom commands and symbols which are not contained in LaTeX or the AMS packages. You can find an example in example.tex if you need further help.

Step 3: Compile the document to see if you did it correctly (it should compile without errors). To do so, you have to compile the file main.tex with pdflatex (again, do not change names and location of other files).

Step 4: Once you have finished writing your abstract, please change lines 6 and 7 in the main.tex file as follows (using %): 
%\MakeAbstract{example}
%newpage

Step 5: Rename the file 'main.pdf' to '[surname]_[name].pdf' (where [surname] is replaced by your last name and [name] by your first name). E.g., if your first name is John and your last name is Doe, name the file 'Doe_John.pdf'.

Step 6: Rename the file 'template.tex' to '[surname]_[name].tex'.

Step 7: Attach the PDF and tex files to the registration form in the website.

If you have any questions, please write to bymat@icmat.es.
